/**
 *  %name.pascal%Props
 */
export type %name.pascal%Props = React.PropsWithChildren & {
};
