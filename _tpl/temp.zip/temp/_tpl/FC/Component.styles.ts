import { makeStyles } from '@griffel/react';

/**
 * Styles for the %name.pascal% slots
 */
export const use%name.pascal%Styles = makeStyles({
  root: {},
});
