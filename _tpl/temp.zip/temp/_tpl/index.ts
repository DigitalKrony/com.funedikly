export { %name.pascal% } from './%name.pascal%';
export type { %name.pascal%Props } from './%name.pascal%.types';
