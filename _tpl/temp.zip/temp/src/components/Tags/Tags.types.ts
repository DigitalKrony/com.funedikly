/**
 *  TagsProps
 */
export type TagsProps = React.PropsWithChildren & {
  tagList: string[];
};
