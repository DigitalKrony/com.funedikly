import { makeStyles } from '@griffel/react';

/**
 * Styles for the Tags slots
 */
export const useTagsStyles = makeStyles({
  root: {},
});
