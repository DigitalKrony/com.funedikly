export { Tags } from './Tags';
export type { TagsProps } from './Tags.types';
