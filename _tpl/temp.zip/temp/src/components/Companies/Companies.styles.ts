import { makeStyles } from '@griffel/react';

/**
 * Styles for the Companies slots
 */
export const useCompaniesStyles = makeStyles({
  root: {},
});
