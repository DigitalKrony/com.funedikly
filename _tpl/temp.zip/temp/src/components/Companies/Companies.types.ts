/**
 *  CompaniesProps
 */
export type CompaniesProps = React.PropsWithChildren & {
};
