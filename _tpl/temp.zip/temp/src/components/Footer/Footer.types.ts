/**
 *  FooterProps
 */
export type FooterProps = {
  children?: React.ReactNode;
};
