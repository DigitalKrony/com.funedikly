export { Footer } from './Footer';
export type { FooterProps } from './Footer.types';
