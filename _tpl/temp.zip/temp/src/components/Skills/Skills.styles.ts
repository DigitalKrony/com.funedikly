import { makeStyles } from '@griffel/react';

/**
 * Styles for the Skills slots
 */
export const useSkillsStyles = makeStyles({
  root: {},
});
