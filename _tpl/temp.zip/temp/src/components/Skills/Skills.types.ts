import * as React from "react";

/**
 *  SkillsProps
 */
export type SkillsProps = React.PropsWithChildren & {
  skillList: string[];
};
