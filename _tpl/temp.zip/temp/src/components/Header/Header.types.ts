/**
 *  HeaderProps
 */
export type HeaderProps = {
  children?: React.ReactNode;
};
