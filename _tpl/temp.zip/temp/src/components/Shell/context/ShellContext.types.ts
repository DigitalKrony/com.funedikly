
export type ShellContextValue = {
  loaded: boolean;
};

export type ShellContextValues = {
  shell: ShellContextValue;
};
