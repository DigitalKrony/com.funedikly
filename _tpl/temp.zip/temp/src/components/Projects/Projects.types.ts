/**
 *  ProjectsProps
 */
export type ProjectsProps = React.PropsWithChildren & {
};
