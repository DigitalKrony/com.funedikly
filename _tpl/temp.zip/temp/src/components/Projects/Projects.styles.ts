import { makeStyles } from '@griffel/react';

/**
 * Styles for the Projects slots
 */
export const useProjectsStyles = makeStyles({
  root: {},
});
