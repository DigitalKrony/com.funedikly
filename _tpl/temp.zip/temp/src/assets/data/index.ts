export const siteData = {
  skills: ['UX Design', 'UX Development'],
  tags: ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React.js', 'Node.js'],
};
