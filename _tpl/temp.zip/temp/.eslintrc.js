module.exports = {
  ignorePatterns: ['_tpl/*'],
  env: {
    es6: true
  },
  rules: {
  },
  "parserOptions": {
        "sourceType": "module",
    }
};
